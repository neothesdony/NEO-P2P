package network.reticulum.common

/**
 * Bounds on msgpack declared lengths (2026-11-03 hardening).
 *
 * `unpackBinaryHeader()` returns an attacker-controlled declared length
 * without checking the remaining payload, and both `ByteArray(len)` and
 * `MessageUnpacker.readPayload(len)` allocate that length up front. A hostile
 * peer can therefore declare a ~2 GB field inside a few bytes and trigger an
 * `OutOfMemoryError`, which `catch (Exception)` does not handle.
 *
 * Every declared length is checked against [MAX_DECLARED_BYTES] before any
 * allocation. The cap is 2 MiB: RNS link/resource fields and LXMF messages are
 * far smaller, while it still admits the app's documented 1 MiB chat
 * attachment plus framing/AEAD overhead.
 */
object MsgPackLimits {
    const val MAX_DECLARED_BYTES = 2 * 1024 * 1024

    fun requireDeclaredLength(len: Int, what: String) {
        require(len in 0..MAX_DECLARED_BYTES) {
            "$what declared length $len exceeds $MAX_DECLARED_BYTES"
        }
    }
}
